
package com.spr.mav.model;


public class Salary {
    
    
    
    private int id;
    
    
    private double bSalary;
    private double specialPay;
    private double increment;
    private double mDeduction;
    private double deduction;
    private double insurance;
    private double loans;
    private double netSalary;
    private String month;
    private String year;
    
    
    
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getbSalary() {
        return bSalary;
    }

    public void setbSalary(double bSalary) {
        this.bSalary = bSalary;
    }

    public double getSpecialPay() {
        return specialPay;
    }

    public void setSpecialPay(double specialPay) {
        this.specialPay = specialPay;
    }

    public double getIncrement() {
        return increment;
    }

    public void setIncrement(double increment) {
        this.increment = increment;
    }

    public double getmDeduction() {
        return mDeduction;
    }

    public void setmDeduction(double mDeduction) {
        this.mDeduction = mDeduction;
    }

    public double getDeduction() {
        return deduction;
    }

    public void setDeduction(double deduction) {
        this.deduction = deduction;
    }

    public double getInsurance() {
        return insurance;
    }

    public void setInsurance(double insurance) {
        this.insurance = insurance;
    }

    public double getLoans() {
        return loans;
    }

    public void setLoans(double loans) {
        this.loans = loans;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
    

  
    
    
    
    
}
