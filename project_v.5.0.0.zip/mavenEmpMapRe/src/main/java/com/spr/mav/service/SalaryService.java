/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spr.mav.service;

import com.spr.mav.dao.impl.ISalaryDAO;
import com.spr.mav.model.Salary;
import com.spr.mav.service.impl.ISalaryService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service(value = "salaryService")
public class SalaryService implements ISalaryService {

    
    @Autowired
    ISalaryDAO salaryDAO;
    
    
    
    
    @Override
    public Salary save(HttpServletRequest request) {
       double bSalary=Double.parseDouble(request.getParameter("bSalary"));
       String month=request.getParameter("month");
       String year=request.getParameter("year");
       
       
       Salary sal=new Salary();
       
       sal.setbSalary(bSalary);
       sal.setMonth(month);
       sal.setYear(year);
       
       return salaryDAO.save(sal);
    }
    
    
    
    

    @Override
    public Salary update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Salary> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
