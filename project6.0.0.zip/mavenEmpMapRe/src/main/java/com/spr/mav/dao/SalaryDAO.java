
package com.spr.mav.dao;

import com.spr.mav.common.ICommonDAO;
import com.spr.mav.dao.impl.ISalaryDAO;
import com.spr.mav.model.Salary;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;



@Repository(value ="salaryDAO")
@Transactional
public class SalaryDAO implements ISalaryDAO{
    
    @Autowired
    SessionFactory sessionFactory;

    
    
    
    
    
    @Override
    public Salary save(Salary t) {
        sessionFactory.getCurrentSession().save(t);
        sessionFactory.getCurrentSession().flush();
        return t;
    }

    
    
    
    
    
    
    
    
    @Override
    public Salary update(Salary t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Salary> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
   

    
    
}
