
package com.spr.mav.model;


public class Salary {
    private int id;
    private int sName;
    private int amount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getsName() {
        return sName;
    }

    public void setsName(int sName) {
        this.sName = sName;
    }

   

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    
    
    
}
