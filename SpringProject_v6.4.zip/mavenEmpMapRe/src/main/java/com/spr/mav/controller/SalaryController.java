
package com.spr.mav.controller;

import com.spr.mav.controller.impl.ISalaryController;
import com.spr.mav.model.Salary;
import com.spr.mav.service.impl.ISalaryService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



@RestController
public class SalaryController implements ISalaryController{
    
    
    @Autowired
    ISalaryService salaryService;
    
    

    @Override
    public ModelAndView create() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    
    
    
    @Override
    @RequestMapping(value = "/saveSalary",method = RequestMethod.POST)
    public ModelAndView save(HttpServletRequest request) {
        salaryService.save(request);
        
        System.out.println("Hitted!");
        return new ModelAndView("/admin/salaryData");
    }

    
    
    
    
    
    
    @Override
    public ModelAndView edit(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    ///////////up
    @Override
     @RequestMapping(value ="/salUpdate", method = RequestMethod.POST)
    public ModelAndView update(HttpServletRequest request) {
         salaryService.update(request);
       return new ModelAndView("/admin/salaryData");
    }

    
    
    
    @Override
    public ModelAndView delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    
    
    @Override
    public List<Salary> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
    
    
    
    @RequestMapping(path="/viTest",method = RequestMethod.POST)
    public ModelAndView incrementT(@RequestParam("specialPay") double specialPay,
            @RequestParam("increment") double increment,
             @RequestParam("bSalary") double bSalary,
            @RequestParam("month") String month,
            @RequestParam("year") String year ,Model model){
        
        
             
          double netSalary=(increment/100)*bSalary+(specialPay/100)*bSalary+bSalary;
        
        
        model.addAttribute("bSalary",bSalary);
        model.addAttribute("netSalary",netSalary);
      
          model.addAttribute("specialPay",specialPay);
          model.addAttribute("increment",increment);
          
        model.addAttribute("month",month);
         model.addAttribute("year",year);
        
        
        return new ModelAndView("/admin/salaryData");
    }
    
    
    
    
    
    
    
     @RequestMapping(path="/viiTest",method = RequestMethod.POST)
    public ModelAndView deductionT(@RequestParam("insurance") double insurance,
            @RequestParam("loans") double loans,
             @RequestParam("mDeduction") double mDeduction,
            @RequestParam("bSalary") double bSalary,
            @RequestParam("month") String month ,
            @RequestParam("year") String year ,
            Model model){
        
        
             
        
        
          
           double netSalary=bSalary-(insurance/100)*bSalary-(loans/100)*bSalary-(mDeduction/100)*bSalary;
        
        model.addAttribute("bSalary",bSalary);
        model.addAttribute("netSalary",netSalary);
      
          model.addAttribute("insurance",insurance);
          model.addAttribute("loans",loans);
           model.addAttribute("mDeduction",mDeduction);
          
        model.addAttribute("month",month);
         model.addAttribute("year",year);
        
        
        return new ModelAndView("/admin/salaryData");
    }

    
    ////increment/////
    @Override
     @RequestMapping(path="/saveIncre",method = RequestMethod.POST)
    public ModelAndView saveIncrementSalary(HttpServletRequest request) {
       salaryService.saveIncrementSalary(request);
        return new ModelAndView("/admin/salaryData");
    }

    
    
    ////Decriment/////
   
     @RequestMapping(path="/saveDecre",method = RequestMethod.POST)
    public ModelAndView saveDecrementSalary(HttpServletRequest request) {
        salaryService.saveDecrementSalary(request);
         return new ModelAndView("/admin/salaryData");
    }
    
    
    
    //////Save to Salary From Employee/////
    
    
   
    
    
    
    @RequestMapping(value = "/empToSalary",method = RequestMethod.POST)
    public ModelAndView empToSave(HttpServletRequest request) {
        salaryService.empToSalary(request);
        
        System.out.println("Hitted!");
        return new ModelAndView("/admin/salaryData");
    }
    
    
    ///////To Show Data from Salary Table//////
    
     @RequestMapping(value ="/salIncreView")
    public ModelAndView viewSalary() {
      List<Salary> salayData = salaryService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("allSalaryData",salayData);
        
      return new ModelAndView("/admin/salaryData","map",map);
        
 }
    
    
    
     /////toSelect
    
    
    @RequestMapping(value = "/selectSal/{id}", method = RequestMethod.GET)
    public ModelAndView selectSalary(ModelMap map, @PathVariable("id") int id) {
        Salary sm = salaryService.getById(id);
        map.addAttribute("sm",sm);
        return  new ModelAndView("/admin/salaryData");
    }
    
    
    /////////Salary Decrement Update ////////

    @Override
     @RequestMapping(value ="/salDecrementUpdate", method = RequestMethod.POST)
    public ModelAndView salaryDecrementUpdate(HttpServletRequest request) {
          salaryService.salaryDecrementUpdate(request);
       return new ModelAndView("/admin/salaryData");
    }
    
    

    
    
  
   
    
    
    
    
    
}


