
package com.spr.mav.dao.impl;

import com.spr.mav.common.ICommonDAO;
import com.spr.mav.model.Employee;




public interface IEmployeeDAO extends ICommonDAO<Employee>{
    
}
