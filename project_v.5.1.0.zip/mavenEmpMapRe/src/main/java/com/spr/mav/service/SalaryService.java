/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spr.mav.service;

import com.spr.mav.dao.impl.ISalaryDAO;
import com.spr.mav.model.Salary;
import com.spr.mav.service.impl.ISalaryService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service(value = "salaryService")
public class SalaryService implements ISalaryService {

    
    @Autowired
    ISalaryDAO salaryDAO;
    
    
    
    
    @Override
    public Salary save(HttpServletRequest request) {
       double bSalary=Double.parseDouble(request.getParameter("bSalary"));
       String month=request.getParameter("month");
       String year=request.getParameter("year");
       
       
       Salary sal=new Salary();
       
       sal.setbSalary(bSalary);
       sal.setMonth(month);
       sal.setYear(year);
       
       return salaryDAO.save(sal);
    }
    
    
    
    

    @Override
    public Salary update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Salary> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Salary getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    ////Increment/////
    @Override
    public Salary saveIncrementSalary(HttpServletRequest request) {
       
        double increment=Double.parseDouble(request.getParameter("increment")); 
        double specialPay=Double.parseDouble(request.getParameter("specialPay"));
        double bSalary=Double.parseDouble(request.getParameter("bSalary"));
        String month=request.getParameter("month");
        String year=request.getParameter("year");
       
       
       Salary sal=new Salary();
       
       double netSalary=(increment/100)*bSalary+(specialPay/100)*bSalary+bSalary;
       
       sal.setIncrement(increment);
       sal.setSpecialPay(specialPay);
       sal.setbSalary(bSalary);
       sal.setNetSalary(netSalary);
       sal.setMonth(month);
       sal.setYear(year);
       
       return salaryDAO.save(sal);
    }

    
    ///decriment///
    @Override
    public Salary saveDecrementSalary(HttpServletRequest request) {
        
        double insurance=Double.parseDouble(request.getParameter("insurance")); 
        double loans=Double.parseDouble(request.getParameter("loans"));
        double mDeduction=Double.parseDouble(request.getParameter("mDeduction"));
        double bSalary=Double.parseDouble(request.getParameter("bSalary"));
        String month=request.getParameter("month");
        String year=request.getParameter("year");
       
       
       Salary sal=new Salary();
       
       double netSalary=bSalary-(insurance/100)*bSalary-(loans/100)*bSalary-(mDeduction/100)*bSalary;
       
       sal.setInsurance(insurance);
       sal.setLoans(loans);
       sal.setmDeduction(mDeduction);
       sal.setbSalary(bSalary);
       sal.setNetSalary(netSalary);
       sal.setMonth(month);
       sal.setYear(year);
       
       return salaryDAO.save(sal);
    }
    
    
    
    
    
    //////Dummy Method/////
    
    @Override
     public Salary empToSalary(HttpServletRequest request) {
        int empid=Integer.parseInt(request.getParameter("empid"));
        String empname=request.getParameter("empname");
        String empdep=request.getParameter("empdep");
        String empdeg=request.getParameter("empdeg");
        double bSalary=Double.parseDouble(request.getParameter("bSalary"));
        
         Salary sal=new Salary();
         sal.setEmpId(empid);
         sal.setEmpName(empname);
         sal.setEmpDep(empdep);
         sal.setEmpDeg(empdeg);
         sal.setbSalary(bSalary);
       
       return salaryDAO.save(sal);
    }
    
}
